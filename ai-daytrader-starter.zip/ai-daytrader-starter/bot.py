"""Conservative delayed-data paper trader; NOT a live execution system."""
import csv, json, math, os
from datetime import datetime, time, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo
import yfinance as yf

ROOT = Path(__file__).parent
CONFIG = json.loads((ROOT / 'config.json').read_text())
STATE_PATH = ROOT / 'data/state.json'
JOURNAL_PATH = ROOT / 'data/trades.csv'
NY = ZoneInfo('America/New_York')
FIELDS = ['timestamp_ny','symbol','side','shares','price_usd','fx_usd_per_eur','fee_eur','pnl_eur','reason','cash_eur','equity_eur']

def persist(state):
    STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    STATE_PATH.write_text(json.dumps(state, indent=2) + '\n')

def record(row):
    new = not JOURNAL_PATH.exists()
    with JOURNAL_PATH.open('a', newline='') as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        if new: w.writeheader()
        w.writerow(row)

def candles(symbol):
    d = yf.download(symbol, period='5d', interval='5m', auto_adjust=True, progress=False, prepost=False, threads=False)
    if d.empty: raise ValueError('No candles: ' + symbol)
    if hasattr(d.columns, 'nlevels') and d.columns.nlevels > 1:
        d.columns = d.columns.get_level_values(0)
    if d.index.tz is None: raise ValueError('Missing timezone')
    return d.tz_convert(NY)

def fx_rate():
    d = yf.download('EURUSD=X', period='5d', interval='5m', progress=False, auto_adjust=True, threads=False)
    if d.empty: raise ValueError('No EURUSD data')
    if hasattr(d.columns, 'nlevels') and d.columns.nlevels > 1: d.columns = d.columns.get_level_values(0)
    ts = d.index[-1]
    if ts.tz is None or datetime.now(tz=ts.tz) - ts > timedelta(minutes=30): raise ValueError('Stale FX')
    fx = float(d['Close'].iloc[-1])
    if not 0.5 < fx < 2.0: raise ValueError('Invalid FX')
    return fx

def main():
    now = datetime.now(NY)
    if now.weekday() >= 5 or not (time(9, 50) <= now.time() <= time(11, 5)):
        print('Outside strategy window'); return
    state = json.loads(STATE_PATH.read_text())
    today = now.date().isoformat()
    if state.get('session') != today:
        state['session'], state['daily_pnl_eur'], state['entries_today'] = today, 0.0, 0
    fx = fx_rate()
    capital = float(CONFIG['starting_capital_eur'])
    equity = float(state['cash_eur']) + sum(float(p['shares'])*float(p['last_usd'])/fx for p in state['positions'].values())
    risk = min(capital, equity)*CONFIG['risk_per_trade_pct']/100
    day_limit = capital*CONFIG['max_daily_loss_pct']/100
    for symbol in CONFIG['symbols']:
        df = candles(symbol)
        df = df[df.index.date == now.date()]
        if len(df) < 5: continue
        # Only completed bars. The current in-progress bar is never traded.
        df = df[df.index + timedelta(minutes=5) <= now - timedelta(minutes=CONFIG['data_delay_minutes'])]
        if len(df) < 4: continue
        first = df.between_time('09:30','09:40')
        if len(first) != 3: continue
        bar = df.iloc[-1]
        bar_time = df.index[-1]
        if now - bar_time > timedelta(minutes=25): continue
        close, low, high = (float(bar[k]) for k in ('Close','Low','High'))
        if not all(math.isfinite(x) and x > 0 for x in (close, low, high)): continue
        pos = state['positions'].get(symbol)
        if pos:
            pos['last_usd'] = close
            # Conservative: stop first if both stop and target touched in same bar.
            exit_price = None; reason = None
            if low <= pos['stop_usd']: exit_price, reason = pos['stop_usd'], 'STOP'
            elif high >= pos['target_usd']: exit_price, reason = pos['target_usd'], 'TARGET'
            if exit_price is not None:
                exit_price *= 1 - CONFIG['slippage_pct']/100
                fee = CONFIG['fee_per_order_eur']
                proceeds = pos['shares']*exit_price/fx - fee
                pnl = proceeds - pos['entry_cost_eur']
                state['cash_eur'] += proceeds
                state['daily_pnl_eur'] += pnl
                del state['positions'][symbol]
                record(dict(timestamp_ny=now.isoformat(),symbol=symbol,side='SELL',shares=pos['shares'],price_usd=round(exit_price,4),fx_usd_per_eur=round(fx,6),fee_eur=fee,pnl_eur=round(pnl,4),reason=reason,cash_eur=round(state['cash_eur'],4),equity_eur=''))
            continue
        if state['daily_pnl_eur'] <= -day_limit or state['entries_today'] >= CONFIG['max_trades_per_day']: continue
        if state['positions']: continue # V1 one position at a time
        opening_high = float(first['High'].max())
        opening_low = float(first['Low'].min())
        typical = (df['High']+df['Low']+df['Close'])/3
        volume = df['Volume']
        if volume.sum() <= 0: continue
        vwap = float((typical*volume).sum()/volume.sum())
        prior = df.iloc[-4:-1]['Volume']
        if len(prior) < 3 or float(prior.mean()) <= 0: continue
        if not (close > opening_high and close > vwap and float(bar['Volume']) >= 1.5*float(prior.mean())): continue
        stop = opening_low
        entry = close*(1+CONFIG['slippage_pct']/100)
        if stop >= entry: continue
        per_share_risk_eur = (entry-stop)/fx
        shares_by_risk = math.floor(max(0,risk-2*CONFIG['fee_per_order_eur'])/per_share_risk_eur)
        shares_by_cash = math.floor(max(0,state['cash_eur']-CONFIG['fee_per_order_eur'])*fx/entry)
        shares = min(shares_by_risk, shares_by_cash)
        if shares < 1: continue
        cost = shares*entry/fx + CONFIG['fee_per_order_eur']
        state['cash_eur'] -= cost
        state['positions'][symbol] = dict(shares=shares,entry_usd=entry,entry_cost_eur=cost,stop_usd=stop,target_usd=entry+2*(entry-stop),last_usd=entry)
        state['entries_today'] += 1
        record(dict(timestamp_ny=now.isoformat(),symbol=symbol,side='BUY',shares=shares,price_usd=round(entry,4),fx_usd_per_eur=round(fx,6),fee_eur=CONFIG['fee_per_order_eur'],pnl_eur='',reason='ORB_VWAP',cash_eur=round(state['cash_eur'],4),equity_eur=''))
    persist(state)
    print(json.dumps({'session':today,'cash_eur':round(state['cash_eur'],2),'positions':state['positions'],'daily_realized_pnl_eur':round(state['daily_pnl_eur'],2)},indent=2))

if __name__ == '__main__':
    main()
