# ai-daytrader — V1 Paper-Trading

**Nur Simulation, keine echten Broker-Orders.** Start 500 EUR; max. 2 % nominales Risiko pro Einstieg, 3 % Tagesverlust auf realisierte P&L, max. 3 Einstiege/Tag. Long-only, ganze Aktien, max. eine Position gleichzeitig.

## Installation vom iPhone
1. Dieses ZIP in der Dateien-App **entpacken**.
2. GitHub-Repository öffnen → **Add file → Upload files** (ggf. Safari „Desktop-Website anfordern“). Alle Dateien und Ordner **einschließlich `.github/workflows/paper-trader.yml`** in die entsprechenden Pfade hochladen. GitHub-Webupload unterstützt Ordner je nach Browser eingeschränkt; falls nötig, Dateien einzeln über **Add file → Create new file** mit Pfad anlegen. ZIP allein hochladen führt **nicht** zu einem laufenden Bot.
3. Unter **Settings → Actions → General → Workflow permissions** „Read and write permissions“ aktivieren, falls nötig.
4. Unter **Actions → Paper Trader (delayed) → Run workflow** manuell starten; Logs prüfen.
5. Nach erfolgreichem Lauf liegen `data/state.json` und ggf. `data/trades.csv` im Repo.

## Strategie
Erste drei 5-Minuten-Kerzen 09:30–09:45 NY definieren die Opening Range. Nach 09:50 NY nur bei Close > OR-High, Close > VWAP und Volumen >= 1,5 × Durchschnitt der letzten drei abgeschlossenen Kerzen kaufen. Stop am OR-Low; Ziel 2R. Stop hat Vorrang, wenn Stop und Ziel in derselben Kerze liegen. Simulierte 0,1 % Slippage und 1 EUR Gebühr je Order. EURUSD wird geprüft; bei fehlenden/stalen Daten wird nicht gehandelt.

## WICHTIGE GRENZEN
- **Prototyp, kein belastbares Backtesting.** Yahoo-Finance-Daten sind nicht garantiert vollständig, live oder für automatisiertes Trading geeignet. Nutzung und Lizenzbedingungen prüfen.
- Zeitverzögerung mindestens 15 Minuten. GitHub Actions läuft nicht minutengenau; Ausführungen können verspätet sein oder ausfallen.
- Cron deckt **nur 14–16 UTC** ab; durch US-Sommer-/Winterzeit und Börsenfeiertage kann es Sitzungen teilweise verpassen. `zoneinfo` begrenzt den Handel auf NY 09:50–11:05.
- **Kein Zwangsschluss am Tagesende**: offene Positionen können über Nacht gehalten werden. Vor echtem Test unbedingt End-of-Day-Exit ergänzen.
- Das Tageslimit bezieht sich auf **realisierte** Verluste; Kurslücken, offene Verluste, Gebühren und Datenfehler können es überschreiten.
- Eröffnungssignal wird bei jeder neuen Kerze erneut bewertet; die Strategie hat noch keine robuste Duplikat-/Reentry-Sperre.
- `SPY` und `QQQ` sind US-ETFs; für Echtgeldhandel in der EU ggf. nicht direkt zugänglich.
- **Nicht mit Trade Republic oder einer Broker-API verbinden.** `allow_live_orders` ist bewusst false.
- GitHub Actions Commit-Konflikte sind möglich; Logs prüfen. Öffentliche Repositories zeigen Journal und Code allen. **Keine Secrets committen.** Repo kann wieder privat gestellt werden.

Für seriösen Einsatz: Tests, Feiertagskalender, robuste Datenquelle, EOD-Exit, offene-P&L-Limits, Kurslückenmodell, Backtest und längerer Forward-Test ergänzen.
